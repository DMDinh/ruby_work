class UsersController < ApplicationController
  def index
    render json: User.all
  end

  def new
  end

  def create
    @user = User.create(name: params[:name])
    redirect_to "/users"
  end

  def show
    session = params[:id]
    user = User.find(session)
    render text: user.name
  end

  def edit

  end

  def total
    render text: User.all
  end


end
