class TimesController < ApplicationController
  def main
    @time = Time.new
  end
end
