require_relative 'human'
class Ninja < Human
  def initialize(name)
    @name = name
    @strength = 10
    @intelligence = 10
    @health = 100
    @stealth = 175
  end

  def steal
    if obj.class.ancestors.include?(Human)
      @health += 10
      puts "Stealth attack!"
      true
    else
      false
    end
    self
  end

  def escape
    @health -= 15
    puts "Escaping!"
  end

  def display_info
    super
    self
  end
end

ninja1 = Ninja.new("Blade")
ninja1.display_info
