require_relative "human"
class Samurai < Human
  def initialize(name)
    @name = name
    @strength = 20
    @intelligence = 20
    @health = 200
    @stealth = 5
  end

  def death_blow
    if obj.class.ancestors.include?(Human)
      obj.health = 0
      puts "Decapitated!"
      true
    else
      false
    end
    self
  end

  def mediate
    @health = 200
    puts "Mediated the situation. Back to 100% health!"
    self
  end

  def how_many
    if obj.class.include?(Samurai)
      count += 1
      puts "There are #{count} samurai's alive!"
      self
    end
  end

  def display_info
    super
    self
  end
end

samurai1 = Samurai.new("Juggernaut")
samurai1.mediate.display_info
